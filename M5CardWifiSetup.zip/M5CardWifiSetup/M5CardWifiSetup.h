#ifndef M5CardWifiSetup_h
#define M5CardWifiSetup_h

#include "Arduino.h"
#include <M5Cardputer.h>
#include <WiFi.h>
#include <Preferences.h>

class M5CardWifiSetup {
public:
    M5CardWifiSetup();
    void begin();
    void loop();

private:
    String inputText(const String& prompt, int x, int y);
    void displayWiFiInfo();
    void connectToWiFi();
    void scanAndDisplayNetworks();
    
    String CFG_WIFI_SSID;
    String CFG_WIFI_PASS;
    static const char* NVS_SSID_KEY;
    static const char* NVS_PASS_KEY;
};

#endif
